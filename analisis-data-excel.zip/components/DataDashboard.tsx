
import React, { useState, useEffect, useMemo } from 'react';
import { FileData, ChartType, AnalysisResult } from '../types.ts';
import { useDataAnalysis } from '../hooks/useDataAnalysis.ts';
import StatCard from './StatCard.tsx';
import { Line, Bar, Scatter } from 'react-chartjs-2';
import { BarChart, LineChart, ScatterChart, Sigma, TrendingUp, Rises, Check, ChevronsLeftRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface DataDashboardProps {
  fileData: FileData;
}

const chartComponents = {
  line: Line,
  bar: Bar,
  scatter: Scatter,
};

const chartIcons = {
  line: <LineChart className="h-5 w-5" />,
  bar: <BarChart className="h-5 w-5" />,
  scatter: <ScatterChart className="h-5 w-5" />,
};

const DataDashboard: React.FC<DataDashboardProps> = ({ fileData }) => {
  const { data, headers } = fileData;
  const [selectedX, setSelectedX] = useState<string>('');
  const [selectedY, setSelectedY] = useState<string>('');
  const [chartType, setChartType] = useState<ChartType>('line');

  useEffect(() => {
    if (headers.length > 0) {
      const firstDateOrTimeColumn = headers.find(h => h.toLowerCase().includes('date') || h.toLowerCase().includes('time') || h.toLowerCase().includes('tanggal') || h.toLowerCase().includes('waktu')) || headers[0];
      const firstNumericColumn = headers.find((h, i) => i > 0 && data.every(row => typeof row[h] === 'number' || !isNaN(Number(row[h])))) || (headers.length > 1 ? headers[1] : headers[0]);
      setSelectedX(firstDateOrTimeColumn);
      setSelectedY(firstNumericColumn);
    }
  }, [headers, data]);

  const analysisResult = useDataAnalysis(data, selectedX, selectedY);

  const chartData = useMemo(() => {
    if (!analysisResult) return { labels: [], datasets: [] };

    const { points, regressionInfo } = analysisResult;
    const labels = points.map(p => p[0].toFixed(2));

    const baseDataset = {
      label: selectedY,
      data: points.map(p => p[1]),
      borderColor: 'rgb(129, 140, 248)', // indigo-400
      backgroundColor: 'rgba(129, 140, 248, 0.5)',
      borderWidth: 2,
      tension: 0.1,
    };

    const datasets = [baseDataset];

    if (chartType === 'scatter' && regressionInfo) {
      datasets.push({
        label: 'Garis Regresi',
        data: [regressionInfo.lineFunction(points[0][0]), regressionInfo.lineFunction(points[points.length - 1][0])],
        borderColor: 'rgb(251, 113, 133)', // rose-400
        backgroundColor: 'rgba(251, 113, 133, 0.5)',
        borderWidth: 2,
        type: 'line' as const,
        pointRadius: 0,
      });
       baseDataset.data = points.map(p => ({x: p[0], y: p[1]}));
    }

    return {
      labels: chartType === 'scatter' ? undefined : labels,
      datasets,
    };
  }, [analysisResult, chartType, selectedY]);

  const chartOptions = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top' as const, labels: { color: '#cbd5e1' } },
      title: { display: true, text: `${selectedY} vs ${selectedX}`, color: '#f8fafc', font: { size: 16 } },
      tooltip: {
        backgroundColor: '#1e293b', // slate-800
        titleColor: '#f8fafc',
        bodyColor: '#cbd5e1',
        borderColor: '#334155', // slate-700
        borderWidth: 1,
      }
    },
    scales: {
      x: {
        type: chartType === 'scatter' ? 'linear' as const : 'category' as const,
        position: 'bottom' as const,
        title: { display: true, text: selectedX, color: '#94a3b8' },
        ticks: { color: '#94a3b8' },
        grid: { color: '#334155' }
      },
      y: {
        title: { display: true, text: selectedY, color: '#94a3b8' },
        ticks: { color: '#94a3b8' },
        grid: { color: '#334155' }
      }
    }
  }), [selectedX, selectedY, chartType]);

  const ChartComponent = chartComponents[chartType];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 glass-card rounded-xl">
        <div className="flex flex-col">
          <label htmlFor="x-axis" className="text-sm font-medium text-slate-300 mb-1">Sumbu X (Independen)</label>
          <select id="x-axis" value={selectedX} onChange={e => setSelectedX(e.target.value)} className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5">
            {headers.map(h => <option key={h} value={h}>{h}</option>)}
          </select>
        </div>
        <div className="flex flex-col">
          <label htmlFor="y-axis" className="text-sm font-medium text-slate-300 mb-1">Sumbu Y (Dependen)</label>
          <select id="y-axis" value={selectedY} onChange={e => setSelectedY(e.target.value)} className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5">
            {headers.map(h => <option key={h} value={h}>{h}</option>)}
          </select>
        </div>
        <div className="flex flex-col">
          <label className="text-sm font-medium text-slate-300 mb-1">Tipe Grafik</label>
          <div className="flex items-center space-x-2 bg-slate-700 rounded-lg p-1">
            {(['line', 'bar', 'scatter'] as ChartType[]).map(type => (
              <button key={type} onClick={() => setChartType(type)} className={`w-full flex justify-center items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${chartType === type ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-600'}`}>
                {chartIcons[type]}
                <span className="capitalize">{type}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Statistics */}
      <AnimatePresence>
        {analysisResult && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6"
          >
            <StatCard title="Jumlah Data" value={analysisResult.stats.count} icon={<Check className="w-6 h-6 text-green-400" />} />
            <StatCard title="Rata-rata" value={analysisResult.stats.mean.toFixed(2)} icon={<Sigma className="w-6 h-6 text-sky-400" />} />
            <StatCard title="Median" value={analysisResult.stats.median.toFixed(2)} icon={<ChevronsLeftRight className="w-6 h-6 text-amber-400" />} />
            <StatCard title="Min / Maks" value={`${analysisResult.stats.min.toFixed(2)} / ${analysisResult.stats.max.toFixed(2)}`} />
            <StatCard title="Std. Deviasi" value={analysisResult.stats.stdDev.toFixed(2)} />
            <StatCard title="R-Squared" value={analysisResult.regressionInfo.rSquared.toFixed(4)} icon={<TrendingUp className="w-6 h-6 text-rose-400" />} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chart */}
      <div className="glass-card p-4 sm:p-6 rounded-xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={chartType}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="chart-container"
          >
            {analysisResult ? (
              <ChartComponent data={chartData} options={chartOptions} />
            ) : (
              <div className="flex items-center justify-center h-full text-slate-400">Pilih kolom numerik untuk Sumbu X dan Y untuk melihat analisis.</div>
            )}
          </motion.div>
        </AnimatePresence>
        {analysisResult && chartType === 'scatter' && (
          <div className="text-center mt-4 text-sm text-slate-300">
            <p><strong>Persamaan Regresi:</strong> {analysisResult.regressionInfo.equation}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default DataDashboard;
