
import React, { useState, useCallback } from 'react';
import { UploadCloud } from 'lucide-react';
import { motion } from 'framer-motion';

interface FileUploadProps {
  onFileUpload: (file: File) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileUpload(e.dataTransfer.files[0]);
      e.dataTransfer.clearData();
    }
  }, [onFileUpload]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileUpload(e.target.files[0]);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        className={`relative flex flex-col items-center justify-center w-full h-96 border-2 border-dashed rounded-xl cursor-pointer transition-colors duration-300 ${
          isDragging ? 'border-indigo-400 bg-slate-800' : 'border-slate-600 hover:border-slate-500'
        }`}
      >
        <input
          type="file"
          id="file-upload"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          onChange={handleFileChange}
          accept=".xlsx, .xls, .csv"
          aria-label="Unggah file"
        />
        <div className="flex flex-col items-center justify-center text-center p-4">
          <UploadCloud className={`w-16 h-16 mb-4 transition-colors ${isDragging ? 'text-indigo-400' : 'text-slate-500'}`} />
          <p className="text-xl font-semibold text-slate-300">
            Seret & Lepas file Excel Anda di sini
          </p>
          <p className="text-slate-400 mt-2">atau</p>
          <label
            htmlFor="file-upload"
            className="mt-2 font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
          >
            Pilih file dari komputer Anda
          </label>
          <p className="mt-4 text-xs text-slate-500">
            Mendukung format .xlsx, .xls
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default FileUpload;
