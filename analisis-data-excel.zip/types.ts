
export type TableRow = Record<string, string | number | Date>;

export interface FileData {
  data: TableRow[];
  headers: string[];
}

export type ChartType = 'line' | 'bar' | 'scatter';

export interface Stats {
  count: number;
  mean: number;
  median: number;
  stdDev: number;
  min: number;
  max: number;
}

export interface RegressionInfo {
  equation: string;
  rSquared: number;
  lineFunction: (x: number) => number;
}

export interface AnalysisResult {
  stats: Stats;
  regressionInfo: RegressionInfo;
  points: [number, number][];
  xValues: number[];
  yValues: number[];
}
