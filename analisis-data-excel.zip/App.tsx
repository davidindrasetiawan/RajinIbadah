
import React, { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { TableRow, FileData } from './types.ts';
import FileUpload from './components/FileUpload.tsx';
import DataDashboard from './components/DataDashboard.tsx';
import { LoaderCircle, AlertTriangle } from 'lucide-react';

const App: React.FC = () => {
  const [fileData, setFileData] = useState<FileData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = useCallback((file: File) => {
    setIsLoading(true);
    setError(null);
    setFileData(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) {
          throw new Error("Gagal membaca file.");
        }
        const workbook = XLSX.read(data, { type: 'array', cellDates: true });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json<TableRow>(worksheet);

        if (jsonData.length === 0) {
          throw new Error("File Excel kosong atau formatnya tidak didukung.");
        }

        const headers = Object.keys(jsonData[0]);
        setFileData({ data: jsonData, headers });
      } catch (err) {
        console.error(err);
        setError(err instanceof Error ? err.message : "Terjadi kesalahan saat memproses file.");
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
        setError("Gagal membaca file. Silakan coba lagi.");
        setIsLoading(false);
    };
    reader.readAsArrayBuffer(file);
  }, []);

  const handleReset = () => {
    setFileData(null);
    setError(null);
  };

  return (
    <main className="min-h-screen w-full bg-slate-900 text-slate-50 p-4 sm:p-6 lg:p-8 font-sans">
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Dasbor Analisis Data
          </h1>
          {fileData && (
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-slate-900 transition-colors"
            >
              Unggah File Baru
            </button>
          )}
        </header>

        {isLoading && (
          <div className="flex flex-col items-center justify-center h-96 text-lg">
            <LoaderCircle className="animate-spin h-12 w-12 mb-4 text-indigo-400" />
            <p>Menganalisis data Anda...</p>
          </div>
        )}

        {error && (
          <div className="glass-card p-6 rounded-xl flex flex-col items-center justify-center h-96 text-lg text-red-400">
            <AlertTriangle className="h-12 w-12 mb-4" />
            <p className="font-semibold">Terjadi Kesalahan</p>
            <p className="text-sm text-slate-400 mt-1">{error}</p>
            <button
              onClick={() => setError(null)}
              className="mt-6 px-4 py-2 bg-red-600 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 focus:ring-offset-slate-900 transition-colors"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {!isLoading && !error && !fileData && (
          <FileUpload onFileUpload={handleFileUpload} />
        )}

        {!isLoading && !error && fileData && (
          <DataDashboard fileData={fileData} />
        )}
      </div>
    </main>
  );
};

export default App;
