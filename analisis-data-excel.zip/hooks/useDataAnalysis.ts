
import { useMemo } from 'react';
import * as ss from 'simple-statistics';
import { TableRow, AnalysisResult } from '../types.ts';

export const useDataAnalysis = (data: TableRow[], xKey: string, yKey: string): AnalysisResult | null => {
  return useMemo(() => {
    if (!xKey || !yKey || data.length === 0) {
      return null;
    }

    const parseValue = (value: any): number => {
        if (value instanceof Date) {
            return value.getTime();
        }
        return parseFloat(String(value));
    }

    const validData = data
      .map(row => ({
        x: parseValue(row[xKey]),
        y: parseValue(row[yKey]),
      }))
      .filter(p => !isNaN(p.x) && !isNaN(p.y));

    if (validData.length < 2) {
      return null;
    }
    
    // Sort by x value for line charts
    validData.sort((a, b) => a.x - b.x);

    const xValues = validData.map(p => p.x);
    const yValues = validData.map(p => p.y);
    const points: [number, number][] = validData.map(p => [p.x, p.y]);

    const regression = ss.linearRegression(points);
    const regressionLine = ss.linearRegressionLine(regression);

    const stats = {
      count: yValues.length,
      mean: ss.mean(yValues),
      median: ss.median(yValues),
      stdDev: ss.standardDeviation(yValues),
      min: ss.min(yValues),
      max: ss.max(yValues),
    };

    const regressionInfo = {
      equation: `y = ${regression.m.toFixed(4)}x + ${regression.b.toFixed(4)}`,
      rSquared: ss.rSquared(points, regressionLine),
      lineFunction: regressionLine,
    };

    return { stats, regressionInfo, points, xValues, yValues };
  }, [data, xKey, yKey]);
};
